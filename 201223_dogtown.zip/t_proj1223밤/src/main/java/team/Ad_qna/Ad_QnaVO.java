package team.Ad_qna;

import java.util.Date;

import org.apache.ibatis.type.Alias;
import org.springframework.web.multipart.MultipartFile;

@Alias("Ad_QnaVO")
public class Ad_QnaVO {

	Integer no;	
	
	String  q_id, q_cate, q_content, q_upfile;	
	MultipartFile upfileFF, upload; 	
	Date q_regdate;
	
	public Integer getNo() {
		return no;
	}
	public void setNo(Integer no) {
		this.no = no;
	}
	public String getQ_id() {
		return q_id;
	}
	public void setQ_id(String q_id) {
		this.q_id = q_id;
	}
	public String getQ_cate() {
		return q_cate;
	}
	public void setQ_cate(String q_cate) {
		this.q_cate = q_cate;
	}
	public String getQ_content() {
		return q_content;
	}
	public void setQ_content(String q_content) {
		this.q_content = q_content;
	}
	
	public String getQ_upfile() {
		return q_upfile;
	}
	public void setQ_upfile(String q_upfile) {
		this.q_upfile = q_upfile;
	}
	public MultipartFile getUpfileFF() {
		return upfileFF;
	}
	public void setUpfileFF(MultipartFile upfileFF) {
		this.upfileFF = upfileFF;
	}
	public MultipartFile getUpload() {
		return upload;
	}
	public void setUpload(MultipartFile upload) {
		this.upload = upload;
	}
	public Date getQ_regdate() {
		return q_regdate;
	}
	public void setQ_regdate(Date q_regdate) {
		this.q_regdate = q_regdate;
	}
	@Override
	public String toString() {
		return "QnaVO [no=" + no + ", q_id=" + q_id + ", q_cate=" + q_cate + ", q_content=" + q_content + ", q_upfile="
				+ q_upfile + ", upfileFF=" + upfileFF + ", upload=" + upload + ", q_regdate=" + q_regdate + "]";
	}
	
	
}
