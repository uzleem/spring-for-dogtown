package team.Ad_qna;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import team.Action;


@Service("ad_qnareply")
public class Ad_reply implements Action{

	@Resource
	Ad_QnaMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		
		System.out.println("qna/modify execute() 실행");
		
		Ad_QnaVO vo = (Ad_QnaVO)map.get("aqvo");
		
		return mapper.detail(vo.no);
	}
	

}
