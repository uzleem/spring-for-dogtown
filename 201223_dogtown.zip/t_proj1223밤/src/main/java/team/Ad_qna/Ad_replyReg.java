package team.Ad_qna;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import team.Action;
import team.mypage.AlertVO;
import team.mypage.FileUploadMM;

@Service("ad_qnareplyReg")
public class Ad_replyReg implements Action{

	@Resource
	Ad_QnaMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		System.out.println("qna/reply execute() 실행");
		
		Ad_QnaVO vo = (Ad_QnaVO)map.get("aqvo");
		vo.setQ_upfile(FileUploadMM.fileUpload(vo.getUpfileFF(), req));
		
		mapper.modify(vo);

		return null;
	}
	

}
