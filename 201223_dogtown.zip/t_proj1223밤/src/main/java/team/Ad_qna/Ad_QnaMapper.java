package team.Ad_qna;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import team.Product.ProductVO;


@Mapper
public interface Ad_QnaMapper {
	
	List<Ad_QnaVO> list();

	List<Ad_QnaVO> list(String pid);
	
	List<Ad_QnaVO> list(String pid, int start, int end);

	int totalCnt();
	
	Ad_QnaVO detail(int no);
	
	void insert(Ad_QnaVO vo);
	
	void insert2(Ad_QnaVO vo);
	
	void modify(Ad_QnaVO vo);
	
	int delete(int vo);
	
}
