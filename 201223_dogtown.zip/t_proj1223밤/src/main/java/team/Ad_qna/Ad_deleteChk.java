package team.Ad_qna;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import team.Action;
import team.mypage.QnaMapper;


@Service("ad_qnadeleteChk")
public class Ad_deleteChk implements Action{

	@Resource
	Ad_QnaMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		
		System.out.println("adqna/deleteChk execute() 실행");
		
		return null;
	}
	

}
