package team.Ad_qna;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import team.Action;
import team.mypage.QnaMapper;


@Service("ad_qnalist")
public class Ad_list implements Action{

	@Resource
	Ad_QnaMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		
		System.out.println("adqna/list execute() 실행");
		
		return mapper.list();
	}
	

}
