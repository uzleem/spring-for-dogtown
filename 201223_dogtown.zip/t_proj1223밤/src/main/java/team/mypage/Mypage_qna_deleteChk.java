package team.mypage;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import team.Action;
import team.customer.CustomerMapper;

@Service("mypagemypage_qna_deleteChk")
public class Mypage_qna_deleteChk implements Action{

	@Resource
	CustomerMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		

		System.out.println("dead/deleteChk execute() 실행") ;
		
		return null;
		
	}
	

}
