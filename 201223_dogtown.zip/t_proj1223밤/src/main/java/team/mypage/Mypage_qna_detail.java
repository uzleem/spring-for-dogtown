package team.mypage;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import team.Action;
import team.customer.CustomerVO;


@Service("mypagemypage_qna_detail")
public class Mypage_qna_detail implements Action{

	@Resource
	QnaMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		
		System.out.println("qna/detail execute() 실행");
		
		CustomerVO vo = (CustomerVO)map.get("cvo");
		
		return mapper.detail(vo.no);
	}
	

}
