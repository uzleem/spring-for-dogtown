package team.mypage;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import team.Action;


@Service("mypagemypage_qna_insertReg")
public class Mypage_qna_insertReg implements Action{

	@Resource
	QnaMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		
		System.out.println("qna/insertReg execute() 실행");
		
		QnaVO vo = (QnaVO)map.get("qnavo");
		vo.setQ_upfile(FileUploadMM.fileUpload(vo.getUpfileFF(), req));
		
		System.out.println("vo.no : " + vo.no);
		
		mapper.insert(vo);
		
		AlertVO avo = new AlertVO();
		avo.setMsg("입력되었습니다.");

		return avo;
	}
	

}
