package team.mypage;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import team.Action;


@Service
public class CkEditorUpload implements Action{
	
	

	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {

		System.out.println("ckEditorUpload execute() 실행");
		
		QnaVO vo = (QnaVO)map.get("qnavo");
		String res = "{\"url\":\"/up/"+FileUploadMM.fileUpload(vo.getUpload(), req)+"\"}";

		return res;
	}
	
	
}
