package team.mypage;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import team.Product.ProductVO;


@Mapper
public interface QnaMapper {
	
	List<QnaVO> list();

	List<QnaVO> list(String pid);
	
	List<QnaVO> list(String pid, int start, int end);

	int totalCnt();
	
	QnaVO detail(int no);
	
	void insert(QnaVO vo);
	
	void insert2(QnaVO vo);
	
	void modify(QnaVO vo);
	
	int delete(int vo);
	
}
