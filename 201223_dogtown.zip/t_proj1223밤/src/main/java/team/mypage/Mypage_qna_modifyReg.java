package team.mypage;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import team.Action;
import team.storage.StorageMapper;
import team.storage.StorageVO;


@Service("mypagemypage_qna_modifyReg")
public class Mypage_qna_modifyReg implements Action{

	@Resource
	QnaMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		System.out.println("qna/modify execute() 실행");
		
		QnaVO vo = (QnaVO)map.get("qnavo");
		vo.setQ_upfile(FileUploadMM.fileUpload(vo.getUpfileFF(), req));
		
		mapper.modify(vo);
		

		return null;
	}
	

}
