package team.mypage;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import team.Action;


@Service("mypagemypage_qna_modifyForm")
public class Mypage_qna_modifyForm implements Action{

	@Resource
	QnaMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		
		System.out.println("qna/modify execute() 실행");
		
		QnaVO vo = (QnaVO)map.get("qnavo");
		
		return mapper.detail(vo.no);
	}
	

}
