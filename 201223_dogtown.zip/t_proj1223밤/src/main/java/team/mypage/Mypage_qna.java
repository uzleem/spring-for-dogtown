package team.mypage;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import team.Action;


@Service("mypagemypage_qna")
public class Mypage_qna implements Action{

	@Resource
	QnaMapper mapper;
	
	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		
		System.out.println("qna/list execute() 실행");
		
		HttpSession session = req.getSession();
		String pid = (String) session.getAttribute("id");

		System.out.println("pid확인"+pid);
		
		return mapper.list(pid);
	}
	

}
