
  package team.payment;
  
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource; 
  import javax.servlet.http.HttpServletRequest;


import org.springframework.stereotype.Service;
  
  import team.Action;
import team.Cart.CartVO;

import team.tms.TmsVO;
  
  @Service("paymentpaymentReg") 
  public class PaymentReg  implements Action{
  
	  @Resource 
	  PaymentMapper mapper;
	  
	  @Override 
	  	public Object execute(HashMap<String, Object> map,HttpServletRequest req) {
			System.out.println("Payment/PaymentReg execute() 실행");		
			TmsVO vo = (TmsVO)map.get("tvo");
			mapper.insertT(vo);	
	
			int [] deleteli;
			//c_code가 int형이라 받아올때 올때 변환이 어려워 name 에 c_code를 a,b,c,형식으로 문자형으로 데려옴
			CartVO cv = (CartVO)map.get("ctvo");
			System.out.println("cartvo를 봐보자 :" + cv);
			
			String [] c_code = cv.getName().split(",");
			System.out.println("c_codr 는" + Arrays.toString(c_code));
			
			for (String str : c_code) {
				 mapper.delete(Integer.parseInt(str));
			}


			System.out.println("@@@after mapper VO:" +vo);
			return null;
	  }
  
  
  }
 