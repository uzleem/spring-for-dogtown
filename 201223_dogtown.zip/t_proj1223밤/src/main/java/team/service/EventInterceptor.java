package team.service;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.HandlerInterceptor;

@Service
public class EventInterceptor implements HandlerInterceptor {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		HttpSession session = request.getSession();
		
		System.out.println("preHandle() 진입");

		String status = "";
		
		if ((String) session.getAttribute("status") != null)
			status = (String) session.getAttribute("status");
		
//		if (!status.equals("admin")) {
//
//			response.sendRedirect("/projectMenu/main/main");
//			return false;
//		}
		return true;
	}

}
