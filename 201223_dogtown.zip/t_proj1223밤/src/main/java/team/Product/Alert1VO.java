package team.Product;

public class Alert1VO {

	String alertMsg, href;

	public String getAlertMsg() {
		return alertMsg;
	}

	public void setAlertMsg(String alertMsg) {
		this.alertMsg = alertMsg;
	}

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	@Override
	public String toString() {
		return "Alert1VO [alertMsg=" + alertMsg + ", href=" + href + "]";
	}
	
	
	
}
